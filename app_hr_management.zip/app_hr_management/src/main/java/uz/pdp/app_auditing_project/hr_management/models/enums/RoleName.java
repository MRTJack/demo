package uz.pdp.app_auditing_project.hr_management.models.enums;

public enum RoleName {
    ROLE_DIRECTOR,
    ROLE_HR_MANAGER,
    ROLE_MANAGER,
    ROLE_EMPLOYEE
}
