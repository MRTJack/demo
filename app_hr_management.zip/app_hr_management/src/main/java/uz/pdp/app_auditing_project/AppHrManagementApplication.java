package uz.pdp.app_auditing_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppHrManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppHrManagementApplication.class, args);
    }

}
